package com.webratio.units.store.commons.resources;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.lang.StringUtils;

import com.webratio.rtx.RTXException;
import com.webratio.rtx.RTXManager;
import com.webratio.rtx.core.SecurityConfig;
import com.webratio.struts.HttpRequestHelper;
import com.webratio.struts.WRGlobals;
import com.webratio.units.store.cloudstorageunit.CloudStorageUnitServlet;

/**
 * This class permits to decorate the fetched resources adding some layout helpful methods.
 */
public class ResourcesDecorator {

    private final String servletPath;
    private final SecurityConfig securityConfig;
    private final HttpRequestHelper requestHelper;

    public ResourcesDecorator(ServletContext sc) throws RTXException {
        this.servletPath = StringUtils.removeEnd((String) sc.getAttribute(CloudStorageUnitServlet.SERVLET_PATH_KEY), "/");
        securityConfig = ((RTXManager) sc.getAttribute(WRGlobals.RTX_KEY)).getModelService().getBLOBSecurityConfig();
        this.requestHelper = (HttpRequestHelper) sc.getAttribute(WRGlobals.HTTP_REQUEST_HELPER_KEY);
    }

    /**
     * Decorates the given list of <code>IResource</code> objects.
     * 
     * @param data
     *            the <code>IResource</code> objects to decorate.
     * @param rtx
     *            the runtime manager.
     * @throws RTXException
     */
    public void decorateResources(List data, Map localContext, RTXManager rtx) throws RTXException {
        List temp = new ArrayList();
        MultiValueMap map = new MultiValueMap();
        for (Iterator iterator = data.iterator(); iterator.hasNext();) {
            IResource resource = (IResource) iterator.next();
            if (IResource.TYPE_FOLDER.equals(resource.getType())) {
                map.put(resource.getName(), resource);
            } else {
                temp.add(resource);
            }
        }
        for (Iterator iterator = map.keySet().iterator(); iterator.hasNext();) {
            List folders = (List) map.getCollection(iterator.next());
            temp.add(new FolderDecorator((IResource[]) folders.toArray(new IResource[0]), this, localContext, rtx));
        }
        data.clear();
        for (Iterator iterator = temp.iterator(); iterator.hasNext();) {
            IResource resource = (IResource) iterator.next();
            if (IResource.TYPE_FILE.equals(resource.getType())) {
                resource = new FileDecorator(resource, servletPath, securityConfig, localContext, requestHelper, rtx);
            }
            data.add(resource);
        }
    }

}
