package com.webratio.units.store.commons.application;

import java.util.HashMap;
import java.util.Map;

import org.dom4j.Element;

import com.webratio.rtx.RTXException;
import com.webratio.rtx.RTXManager;
import com.webratio.rtx.core.AbstractService;
import com.webratio.units.store.commons.resources.IResource;

public abstract class AbstractApplicationService extends AbstractService implements IApplication {

    public AbstractApplicationService(String id, RTXManager mgr, Element descr) {
        super(id, mgr, descr);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IApplication#useLocalLoginPage()
     */
    public boolean useLocalLoginPage() {
        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.rtx.RTXService#dispose()
     */
    public void dispose() {

    }

    protected IResource locateCachedResource(String path, Map localContext) throws RTXException {
        Map cache = (Map) localContext.get(getId() + "Cache");
        if (cache == null) {
            cache = new HashMap();
            localContext.put(getId() + "Cache", cache);
        }
        return (IResource) cache.get(path);
    }

    protected void cacheResource(IResource resource, Map localContext) {
        if (resource == null) {
            return;
        }
        Map cache = (Map) localContext.get(getId() + "Cache");
        if (cache == null) {
            cache = new HashMap();
            localContext.put(getId() + "Cache", cache);
        }
        cache.put(resource.getPath(), resource);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o) {
        if (o instanceof IIdentifiable) {
            return getName().compareToIgnoreCase(((IIdentifiable) o).getName());
        }
        return 0;
    }

}
