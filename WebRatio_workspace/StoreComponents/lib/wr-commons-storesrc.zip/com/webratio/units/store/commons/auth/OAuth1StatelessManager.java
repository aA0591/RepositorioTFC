package com.webratio.units.store.commons.auth;

import java.util.Map;

import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.methods.HttpRequestBase;

import com.webratio.rtx.RTXException;

/**
 * The implementation of the <code>IOAuthManager</code> based on <code>OAuth 1.0</code> protocol.
 */
public class OAuth1StatelessManager extends AbstractAuthorizationManager {

    private static final long serialVersionUID = 1L;

    private final CommonsHttpOAuthConsumer consumer;

    public OAuth1StatelessManager(String apiKey, String apiSecret, IAuthorizationAwareService service) {
        super(service);
        this.consumer = new CommonsHttpOAuthConsumer(apiKey, apiSecret);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialunit.IAuthManager#computeAuthorizationUrl()
     */
    public String getAuthorizationUrl(String callbackURL) throws RTXException {
        throw new RTXException("Do not have to be called for OAuth2StatelessManager!");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialloginunit.IAuthManager#authorize(java.util.Map, java.util.Map)
     */
    public boolean authorize(Map localContext, Map sessionContext) throws RTXException {
        throw new RTXException("Do not have to be called for OAuth2StatelessManager!");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialunit.IOAuthManager#setAccessToken(com.webratio.units.store.socialunit.AccessToken)
     */
    public void setAccessToken(AccessToken accessToken) {
        this.accessToken = accessToken;
        if (accessToken != null) {
            String[] token = StringUtils.split(accessToken.getValue(), "|");
            consumer.setTokenWithSecret(token[0], token[1]);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IAuthManager#sign(org.apache.http.client.methods.HttpRequestBase)
     */
    public void sign(HttpRequestBase request) throws RTXException {
        try {
            consumer.sign(request);
        } catch (Exception e) {
            throw new RTXException("Unable to sign the given request", e);
        }
    }

}