package com.webratio.units.store.commons.auth;

import java.io.Serializable;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.webratio.rtx.RTXException;

/**
 * The access token used by the authorization aware services.
 */
public class AccessToken implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final String COOKIE_ENCODING = "ISO-8859-1";
    private static final String COOKIE_SUFFIX = "AccessToken";
    private static final String INVALID_TOKEN = "NULL";

    private final String value;
    private final String cookieName;
    private int expires = 3600 * 24 * 30;

    public AccessToken(IAuthorizationAwareService service, String value) {
        this.cookieName = getCookieName(service);
        this.value = value;
    }

    public AccessToken(String value) {
        this.cookieName = null;
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setExpires(int expires) {
        if (expires > 0) {
            this.expires = expires;
        }
    }

    public static AccessToken loadFromCookie(IAuthorizationAwareService service, HttpServletRequest request) throws RTXException {
        String _name = getCookieName(service);
        Cookie[] cookies = request.getCookies();
        if (ArrayUtils.isEmpty(cookies)) {
            return null;
        }
        Cookie cookie = null;
        for (int i = 0; i < cookies.length; i++) {
            if (_name.equals(cookies[i].getName())) {
                cookie = cookies[i];
            }
        }
        if (cookie == null) {
            return null;
        }
        String value = cookie.getValue();
        try {
            value = URLDecoder.decode(value, "ISO-8859-1");
            value = new String(Base64.decodeBase64(value.getBytes(COOKIE_ENCODING)), COOKIE_ENCODING);
        } catch (Exception e) {
            throw new RTXException("Unable to read the access cookie for service '" + service.getName() + "'", e);
        }
        if (StringUtils.isBlank(value) || INVALID_TOKEN.equals(value)) {
            return null;
        }
        AccessToken accessToken = new AccessToken(service, value);
        accessToken.setExpires(cookie.getMaxAge());
        return accessToken;
    }

    public void storeToCookie(HttpServletRequest request, HttpServletResponse response) throws RTXException {
        try {
            String _value = value;
            _value = new String(Base64.encodeBase64(_value.getBytes(COOKIE_ENCODING)), COOKIE_ENCODING);
            _value = URLEncoder.encode(_value, COOKIE_ENCODING);
            Cookie accessCookie = new Cookie(cookieName, _value);
            accessCookie.setPath(request.getContextPath());
            accessCookie.setMaxAge(expires);
            response.addCookie(accessCookie);
        } catch (Exception e) {
            throw new RTXException("Unable to store the access cookie for service '" + cookieName + "'", e);
        }
    }

    public static void invalidate(IAuthorizationAwareService service, HttpServletRequest request, HttpServletResponse response)
            throws RTXException {
        try {

            /* creates the invalid access cookie */
            String _name = getCookieName(service);
            String value = INVALID_TOKEN;
            value = new String(Base64.encodeBase64(value.getBytes(COOKIE_ENCODING)), COOKIE_ENCODING);
            value = URLEncoder.encode(value, COOKIE_ENCODING);
            Cookie accessCookie = new Cookie(_name, value);
            accessCookie.setPath(request.getContextPath());
            accessCookie.setMaxAge(0);
            response.addCookie(accessCookie);

            /* invalidate request cookies */
            Cookie[] cookies = request.getCookies();
            if (!ArrayUtils.isEmpty(cookies)) {
                for (int i = 0; i < cookies.length; i++) {
                    if (_name.equals(cookies[i].getName())) {
                        cookies[i].setValue(value);
                        cookies[i].setMaxAge(0);
                    }
                }
            }
        } catch (Exception e) {
            throw new RTXException("Unable to store the access cookie for service '" + service.getName() + "'", e);
        }

    }

    private static String getCookieName(IAuthorizationAwareService service) {
        return StringUtils.capitalize(service.getName()) + COOKIE_SUFFIX;
    }

}
