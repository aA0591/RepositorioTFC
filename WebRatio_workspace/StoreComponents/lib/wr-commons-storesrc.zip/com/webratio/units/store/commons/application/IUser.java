package com.webratio.units.store.commons.application;

import java.io.Serializable;

import com.webratio.rtx.RTXBLOBData;

/**
 * The generic interface of social networks user.
 */
public interface IUser extends Serializable {

    /**
     * Gets the user identifier within the social network.
     * 
     * @return the user identifier.
     */
    public String getId();

    /**
     * Gets the user name.
     * 
     * @return the user name.
     */
    public String getUserName();

    /**
     * Gets the user profile image <code>RTXBLOBData</code>.
     * 
     * @return the user profile image
     */
    public RTXBLOBData getProfileImage();

    /**
     * Gets the large user profile image <code>RTXBLOBData</code>.
     * 
     * @return the user profile image
     */
    public RTXBLOBData getLargeProfileImage();

    /**
     * Gets the EMail address.
     * 
     * @return the EMail address.
     */
    public String getEmail();

    /**
     * Gets the web application the user belongs to.
     * 
     * @return the web application.
     */
    public IApplication getApplication();

}
