package com.webratio.units.store.commons.application;

import java.util.Map;

import org.dom4j.Element;

import com.webratio.rtx.RTXException;
import com.webratio.rtx.RTXManager;
import com.webratio.rtx.core.BeanHelper;
import com.webratio.units.store.commons.auth.IAuthManager;

public abstract class AbstractOAuthableApplicationService extends AbstractApplicationService {

    public AbstractOAuthableApplicationService(String id, RTXManager mgr, Element descr) {
        super(id, mgr, descr);
    }

    protected String obtainAccessToken(Map localContext, Map sessionContext) throws RTXException {
        String accessToken = BeanHelper.asString(localContext.get(localContext.get("unitId") + ".accessToken"));

        if ((accessToken == null) || (accessToken.equals(""))) {
            IAuthManager authMgr = locateOAuthManager(localContext, sessionContext);
            accessToken = authMgr.getAccessToken().getValue();
        }
        return accessToken;
    }

    protected abstract IAuthManager locateOAuthManager(Map localContext, Map sessionContext) throws RTXException;

}
