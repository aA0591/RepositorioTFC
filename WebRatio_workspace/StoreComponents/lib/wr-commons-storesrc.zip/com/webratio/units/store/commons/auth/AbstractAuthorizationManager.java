package com.webratio.units.store.commons.auth;

import java.util.Map;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;

import com.webratio.rtx.RTXException;

public abstract class AbstractAuthorizationManager implements IAuthManager {

    private static final long serialVersionUID = 1L;

    protected final IAuthorizationAwareService service;

    /** The authorization access token */
    protected AccessToken accessToken;

    /** The HTTP client */
    private final HttpClient httpClient;

    public AbstractAuthorizationManager(IAuthorizationAwareService service) {
        this.service = service;

        /* creates the http client */
        SchemeRegistry schemeRegistry = new SchemeRegistry();
        schemeRegistry.register(new Scheme("http", 80, PlainSocketFactory.getSocketFactory()));
        schemeRegistry.register(new Scheme("https", 443, SSLSocketFactory.getSocketFactory()));
        ThreadSafeClientConnManager cm = new ThreadSafeClientConnManager(schemeRegistry);
        cm.setMaxTotal(200);
        cm.setDefaultMaxPerRoute(20);
        httpClient = new DefaultHttpClient(cm);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IAuthManager#getHTTPClient()
     */
    public HttpClient getHTTPClient() {
        return httpClient;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialunit.IOAuthManager#getAccessToken()
     */
    public AccessToken getAccessToken() {
        return accessToken;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialunit.IOAuthManager#setAccessToken(com.webratio.units.store.socialunit.AccessToken)
     */
    public void setAccessToken(AccessToken accessToken) {
        this.accessToken = accessToken;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialunit.IOAuthManager#isAuthorized()
     */
    public boolean isAuthorized() {
        return accessToken != null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IAuthManager#sign(org.apache.http.client.methods.HttpRequestBase)
     */
    public void sign(HttpRequestBase request) throws RTXException {

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IAuthManager#sign(java.util.Map)
     */
    public void sign(Map parameters) throws RTXException {

    }

}
