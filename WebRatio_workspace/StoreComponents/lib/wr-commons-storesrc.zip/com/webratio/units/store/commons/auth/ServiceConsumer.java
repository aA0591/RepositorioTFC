package com.webratio.units.store.commons.auth;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.io.StringWriter;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.FileEntity;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.entity.SerializableEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.dom4j.Document;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.json.JSONObject;

import com.webratio.rtx.RTXBLOBData;
import com.webratio.rtx.RTXException;
import com.webratio.rtx.core.BeanHelper;
import com.webratio.units.store.commons.resources.InputStreamKnownSizeBody;

/**
 * The service consumer is responsible to invoke a certain remote service signing the requests depending on the underlying
 * authentication system.
 */
public class ServiceConsumer {

    private final URI baseURI;
    private final Map baseParameters;
    private final IAuthManager authManager;

    /**
     * Constructs a new <code>ServiceConsumer</code>.
     * <p>
     * Input example:
     * <p>
     * <code>endpointURL = "https://graph.facebook.com/me/friends[fields=id,name,username,email,location|type=user]"</code>
     * <p>
     * Output example:
     * <p>
     * <code>baseURI = "https://graph.facebook.com/me/friends"</code> <br>
     * <code>baseParameters = {["fields","id,name,username,email,location"],["type","user"]}</code>
     * 
     * @param endpointURL
     *            the service endpoint URL.
     * @param authManager
     *            the <code>IAuthManager</code> implementation.
     * @throws RTXException
     */
    public ServiceConsumer(String endpointURL, IAuthManager authManager) throws RTXException {
        this.authManager = authManager;
        try {
            String parameters = null;
            String uri = endpointURL;
            if (uri.endsWith("]")) {
                parameters = StringUtils.substringAfter(uri, "[");
                parameters = StringUtils.substringBeforeLast(parameters, "]");
                uri = StringUtils.substringBefore(uri, "[");
            }
            uri = escapeURI(uri);
            baseURI = new URI(uri);
            if (!StringUtils.isBlank(parameters)) {
                Map temp = new HashMap();
                String[] tokens = StringUtils.split(parameters, "|");
                for (int i = 0; i < tokens.length; i++) {
                    String paramName = StringUtils.substringBefore(tokens[i], "=");
                    String paramValue = StringUtils.substringAfter(tokens[i], "=");
                    temp.put(paramName, paramValue);
                }
                baseParameters = Collections.unmodifiableMap(temp);
            } else {
                baseParameters = null;
            }
        } catch (Exception e) {
            throw new RTXException("Unable to parse the service endpoint URL: " + endpointURL, e);
        }
    }

    /**
     * Gets the service encoded endpoint URL.
     * 
     * @return the service encoded endpoint URL.
     * @throws RTXException
     */
    public String getEndpointURL() throws RTXException {
        return getEndpointURL(null);
    }

    /**
     * Gets the service encoded endpoint URL.
     * 
     * @param the
     *            parameters to append to the result URL.
     * @return the service endpoint URL.
     * @throws RTXException
     */
    public String getEndpointURL(Map parameters) throws RTXException {
        return computeURI(parameters).toASCIIString();
    }

    /**
     * Executes a signed request to the service using the <code>GET</code> method.
     * 
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doGet() throws RTXException {
        return doGet(null);
    }

    /**
     * Executes a signed request to the service using the <code>GET</code> method.
     * 
     * @param parameters
     *            the map containing the parameters to send to the service.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doGet(Map parameters) throws RTXException {
        return doGet(parameters, null);
    }

    /**
     * 
     * @param parameters
     *            map containing request parameters to send to the service
     * @param headers
     *            map containing the required headers of the request
     * @return
     * @throws RTXException
     */
    public HttpResponse doGet(Map parameters, Map headers) throws RTXException {
        try {
            parameters = (parameters == null) ? new HashMap() : parameters;
            authManager.sign(parameters);
            HttpRequestBase request = new HttpGet(computeURI(parameters));
            // request.setHeader("Content-Type", "application/xml");
            addHeadersToRequest(headers, request);
            authManager.sign(request);
            HttpResponse response = authManager.getHTTPClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform request", e);
        }
    }

    /**
     * 
     * @param parameters
     *            map containing request parameters to send to the service
     * @param headers
     *            map containing the required headers of the request
     * @return
     * @throws RTXException
     */
    public HttpResponse doGetWithoutToken(Map parameters, Map headers) throws RTXException {
        try {
            parameters = (parameters == null) ? new HashMap() : parameters;
            HttpRequestBase request = new HttpGet(computeURI(parameters));
            addHeadersToRequest(headers, request);
            authManager.sign(request);
            HttpResponse response = (authManager.getHTTPClient()).execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform request", e);
        }
    }

    /**
     * Executes a signed request to the service using the <code>POST</code> method.
     * 
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doPost() throws RTXException {
        return doPost(null);
    }

    /**
     * Executes a signed request to the service using the <code>POST</code> method.
     * 
     * @param parameters
     *            the map containing the parameters to send to the service.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doPost(Map parameters) throws RTXException {
        try {
            parameters = (parameters == null) ? new HashMap() : parameters;
            authManager.sign(parameters);
            HttpPost request = new HttpPost(baseURI);
            request.setEntity(computeRequestEntity(parameters));
            authManager.sign(request);
            HttpResponse response = authManager.getHTTPClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform request", e);
        }
    }

    /**
     * Executes a request to the service using the <code>POST</code> method and setting a request JSON body.
     * 
     * @param requestObject
     *            the JSON object to be POSTed.
     * @param queryStringParameters
     *            the map containing the parameters to include in the request query string.
     * @param headhers
     *            the HTTP headers to be included in the HTTP request.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doJsonPost(JSONObject requestObject, Map queryStringParameters, Map headers) throws RTXException {
        try {
            headers.put("Content-Type", "application/json");
            queryStringParameters = (queryStringParameters == null) ? new HashMap() : queryStringParameters;
            HttpPost request = new HttpPost(computeURI(queryStringParameters));
            request.setEntity(new StringEntity(requestObject.toString()));
            addHeadersToRequest(headers, request);
            HttpResponse response = authManager.getHTTPClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform request", e);
        }
    }

    /**
     * Executes a request to the service using the <code>PUT</code> method and setting a request JSON body.
     * 
     * @param requestObject
     *            the JSON object to attach.
     * @param queryStringParameters
     *            the map containing the parameters to include in the request query string.
     * @param headhers
     *            the HTTP headers to be included in the HTTP request.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doJsonPut(JSONObject requestObject, Map queryStringParameters, Map headers) throws RTXException {
        try {
            headers.put("Content-Type", "application/json");
            queryStringParameters = (queryStringParameters == null) ? new HashMap() : queryStringParameters;
            HttpPut request = new HttpPut(computeURI(queryStringParameters));
            request.setEntity(new StringEntity(requestObject.toString()));
            addHeadersToRequest(headers, request);
            HttpResponse response = authManager.getHTTPClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform request", e);
        }
    }

    /**
     * Executes a request to the service using the <code>POST</code> method to upload a file.
     * 
     * @param blobData
     *            the object wrapping the file to upload.
     * @param queryStringParameters
     *            the map containing the parameters to include in the request query string.
     * @param headhers
     *            the HTTP headers to be included in the HTTP request.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doFilePost(RTXBLOBData blobData, Map queryStringParameters, Map headers) throws RTXException {
        try {
            queryStringParameters = (queryStringParameters == null) ? new HashMap() : queryStringParameters;
            HttpPost request = new HttpPost(computeURI(queryStringParameters));
            InputStream is = blobData.openFileInputStream();
            File f = new File(System.getProperty("java.io.tmpdir"), blobData.getName());
            f.deleteOnExit();
            OutputStream out = new BufferedOutputStream(new FileOutputStream(f));
            IOUtils.copy(is, out);
            IOUtils.closeQuietly(is);
            IOUtils.closeQuietly(out);
            addHeadersToRequest(headers, request);
            request.setEntity(new FileEntity(f, ""));
            HttpResponse response = authManager.getHTTPClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform request", e);
        }
    }

    /**
     * Executes an unsigned POST using the given parameters.
     * 
     * @param parameters
     *            the parameters being posted.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service.
     */
    public HttpResponse doUnsignedPost(Map parameters) throws RTXException {
        try {
            parameters = (parameters == null) ? new HashMap() : parameters;
            // authManager.sign(parameters);
            HttpPost request = new HttpPost(baseURI);
            // HttpRequestBase request = new HttpGet(computeURI(parameters));
            request.setEntity(computeRequestEntity(parameters));
            // authManager.sign(request);
            HttpResponse response = new DefaultHttpClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform request", e);
        }
    }

    /**
     * Executes an unsigned GET using the given parameters.
     * 
     * @param parameters
     *            the parameters being sent.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service.
     */
    public HttpResponse doUnsignedGet() throws RTXException {
        Map parameters = null;
        try {
            parameters = (parameters == null) ? new HashMap() : parameters;
            HttpRequestBase request = new HttpGet(computeURI(parameters));
            HttpResponse response = new DefaultHttpClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform request", e);
        }
    }

    /**
     * Executes a signed request to the service using the <code>DELETE</code> method.
     * 
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doDelete() throws RTXException {
        return doDelete(null);
    }

    /**
     * Executes a signed request to the service using the <code>DELETE</code> method.
     * 
     * @param headers
     *            the headers being sent.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doDelete(Map headers) throws RTXException {
        try {
            Map parameters = new HashMap();
            authManager.sign(parameters);
            HttpDelete request = new HttpDelete(computeURI(parameters));
            addHeadersToRequest(headers, request);
            authManager.sign(request);
            HttpResponse response = authManager.getHTTPClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform delete request", e);
        }
    }

    /**
     * Executes a request to the service using the <code>DELETE</code> method.
     * 
     * @param parameters
     *            the map containing the parameters to be included in the request query string.
     * @param headers
     *            the headers being sent.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse doDelete(Map parameters, Map headers) throws RTXException {
        try {
            HttpDelete request = new HttpDelete(computeURI(parameters));
            addHeadersToRequest(headers, request);
            HttpResponse response = authManager.getHTTPClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to perform delete request", e);
        }
    }

    /**
     * Send to the service the serialization of the given object.
     * 
     * @param object
     *            the object to send.
     * @param method
     *            the method to use (PUT, POST).
     * 
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse send(Object object, String method) throws RTXException {
        return send(object, null, method);
    }

    /**
     * Send to the service the serialization of the given object.
     * 
     * @param object
     *            the object to send.
     * @param method
     *            the method to use (PUT, POST).
     * @param headers
     *            the headers being sent.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse send(Object object, String method, Map headers) throws RTXException {
        return send(object, null, method, null, headers);
    }

    /**
     * Send to the service a BLOB through a signed request using the given method.
     * 
     * @param object
     *            the object to send.
     * @param parameters
     *            the map containing the parameters to send to the service.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse send(Object object, Map parameters, String method) throws RTXException {
        return send(object, parameters, method, null);
    }

    /**
     * Send to the service a BLOB through a signed request using the given method.
     * 
     * @param object
     *            the object to send.
     * @param parameters
     *            the map containing the parameters to send to the service.
     * @param multipartName
     *            the object multipart name, can be null.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse send(Object object, Map parameters, String method, String multipartName) throws RTXException {
        return send(object, parameters, method, multipartName, null);
    }

    /**
     * Send to the service a BLOB through a signed request using the given method.
     * 
     * @param object
     *            the object to send.
     * @param parameters
     *            the map containing the parameters to send to the service.
     * @param multipartName
     *            the object multipart name, can be null.
     * @param headers
     *            the headers being sent.
     * @return the <code>HTTPResponse</code> object.
     * @throws RTXException
     *             in case an error occurs invoking the service, or the response status is not <code>200</code>.
     */
    public HttpResponse send(Object object, Map parameters, String method, String multipartName, Map headers) throws RTXException {
        try {
            parameters = (parameters == null) ? new HashMap() : parameters;
            authManager.sign(parameters);
            HttpEntityEnclosingRequestBase request = null;
            if (HttpPut.METHOD_NAME.equals(method)) {
                request = new HttpPut(computeURI(parameters));
            } else if (HttpPost.METHOD_NAME.equals(method)) {
                request = new HttpPost(computeURI(parameters));
            }
            HttpEntity reqEntity = null;
            if (object instanceof RTXBLOBData) {
                RTXBLOBData blobData = (RTXBLOBData) object;
                if (multipartName != null) {
                    reqEntity = new MultipartEntity(HttpMultipartMode.STRICT);
                    ((MultipartEntity) reqEntity).addPart(multipartName, new InputStreamKnownSizeBody(blobData.openFileInputStream(),
                            blobData.getLength(), blobData.getName()));
                } else {
                    reqEntity = new InputStreamEntity(blobData.openFileInputStream(), blobData.getLength());
                }
            } else if (object instanceof Document) {
                reqEntity = new StringEntity(toXMLString((Document) object), "text/xml", "UTF-8");
            } else if (object instanceof JSONObject) {
                reqEntity = new StringEntity(object.toString(), "application/json", "UTF-8");
            } else if (object instanceof Serializable) {
                reqEntity = new SerializableEntity((Serializable) object, false);
            }
            if (reqEntity != null) {
                request.setEntity(reqEntity);
            }
            addHeadersToRequest(headers, request);
            authManager.sign(request);
            HttpResponse response = authManager.getHTTPClient().execute(request);
            checkError(response);
            return response;
        } catch (Exception e) {
            throw new RTXException("Unable to send '" + object + "' to: " + baseURI, e);
        }

    }

    protected void checkError(HttpResponse response) throws RTXException {
        if (response == null) {
            throw new RTXException("Null response from service");
        }
        int statusCode = response.getStatusLine().getStatusCode();
        if (statusCode < HttpStatus.SC_OK || statusCode >= HttpStatus.SC_MULTIPLE_CHOICES) {
            switch (statusCode) {
            case HttpStatus.SC_NOT_FOUND:
                return;
            case HttpStatus.SC_UNAUTHORIZED:
                throw new InvalidAccessTokenException("Unauthorized request");
            default:
                throw new RTXException(StringUtils.defaultIfEmpty(getErrorMessage(response), "Invalid response: " + response));
            }
        }
    }

    protected String getErrorMessage(HttpResponse response) {
        HttpEntity entity = response.getEntity();
        StringBuffer buf = new StringBuffer();
        buf.append("Invalid response (statusCode ");
        buf.append(response.getStatusLine().getStatusCode());
        buf.append(")");
        if (entity != null) {
            try {
                buf.append(" - ").append(HttpResponseReader.getContentAsString(response));
            } catch (Exception e) {
                // ignores exceptions
            }
        }
        return buf.toString();
    }

    private URI computeURI(Map parameters) throws RTXException {
        try {
            Map temp = new HashMap();
            if (baseParameters != null) {
                temp.putAll(baseParameters);
            }
            if (parameters != null) {
                temp.putAll(parameters);
            }
            List nameValuePairs = new ArrayList();
            for (Iterator iterator = temp.entrySet().iterator(); iterator.hasNext();) {
                Entry entry = (Entry) iterator.next();
                nameValuePairs.add(new BasicNameValuePair(BeanHelper.asString(entry.getKey()), BeanHelper.asString(entry.getValue())));
            }
            return URIUtils.createURI(baseURI.getScheme(), baseURI.getHost(), baseURI.getPort(), escapeURI(baseURI.getPath()),
                    escapeURI(StringUtils.defaultIfEmpty(URLEncodedUtils.format(nameValuePairs, "UTF-8"), null)), null);
        } catch (Exception e) {
            throw new RTXException("Unable to compute the URL for: " + baseURI.toString(), e);
        }
    }

    private HttpEntity computeRequestEntity(Map parameters) throws RTXException {
        try {
            Map temp = new HashMap();
            if (baseParameters != null) {
                temp.putAll(baseParameters);
            }
            if (parameters != null) {
                temp.putAll(parameters);
            }
            List parameterList = new ArrayList();
            for (Iterator iterator = temp.entrySet().iterator(); iterator.hasNext();) {
                Entry entry = (Entry) iterator.next();
                parameterList.add(new BasicNameValuePair(BeanHelper.asString(entry.getKey()), BeanHelper.asString(entry.getValue())));
            }
            return new UrlEncodedFormEntity(parameterList, "UTF-8");
        } catch (Exception e) {
            throw new RTXException("Unable to compute the request entity for: " + baseURI.toString(), e);
        }
    }

    private static String escapeURI(String str) {
        if (!StringUtils.isBlank(str)) {
            str = StringUtils.replace(str, " ", "%20");
            str = StringUtils.replace(str, "+", "%20");
        }
        return str;
    }

    private static String toXMLString(Document doc) throws RTXException {
        StringWriter sw = new StringWriter();
        try {
            OutputFormat outFormat = OutputFormat.createPrettyPrint();
            outFormat.setEncoding("UTF-8");
            XMLWriter xmlWriter = new XMLWriter(sw, outFormat);
            xmlWriter.setMaximumAllowedCharacter(127);
            xmlWriter.write(doc);
            xmlWriter.flush();
            xmlWriter.close();
            sw.flush();
            sw.close();
            return StringUtils.stripStart(sw.toString(), null);
        } catch (Exception e) {
            throw new RTXException("Unable to serialize the document", e);
        } finally {
            IOUtils.closeQuietly(sw);
        }
    }

    private static void addHeadersToRequest(Map headers, HttpRequestBase request) {
        if (headers != null) {
            Iterator it = headers.keySet().iterator();
            while (it.hasNext()) {
                Object next = it.next();
                request.setHeader(next.toString(), headers.get(next).toString());
            }
        }
    }
}
