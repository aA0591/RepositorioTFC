package com.webratio.units.store.commons.application;

import java.io.InputStream;
import java.util.Map;

import com.webratio.rtx.RTXBLOBData;
import com.webratio.rtx.RTXException;
import com.webratio.rtx.RTXService;
import com.webratio.units.store.commons.auth.IAuthorizationAwareService;
import com.webratio.units.store.commons.resources.IResource;

public interface IStorageService extends RTXService, IAuthorizationAwareService, IApplication {

    /**
     * Retrieves the metadata for the given path.
     * 
     * @param path
     *            the path to the file or folder.
     * @param localContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = request).
     * @param sessionContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = session).
     * @return the array of retrieved <code>IResource</code> objects.
     * @throws RTXException
     */
    public IResource findResource(String path, Map localContext, Map sessionContext) throws RTXException;

    /**
     * Retrieves member resources (file and folders)
     * 
     * @param resource
     *            the resource whose members must be retrieved.
     * @return the array of retrieved <code>IResource</code> objects.
     * @throws RTXException
     */
    public IResource[] findMembers(IResource resource) throws RTXException;

    /**
     * Retrieves a certain cloud stored resource and serializes it to the given output stream.
     * 
     * @param resource
     *            the resource to read.
     * @return the input stream of the resource.
     * @throws RTXException
     */
    public InputStream openInputStream(IResource resource) throws RTXException;

    /**
     * Writes the given <code>RTXBLOBData</code> to the specified remote path.
     * 
     * @param blobData
     *            the blob data being uploaded.
     * @param path
     *            the target storage path.
     * @param localContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = request).
     * @param sessionContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = session).
     * @return the created file resource.
     * @throws RTXException
     */
    public IResource write(RTXBLOBData blobData, String path, Map localContext, Map sessionContext) throws RTXException;

    /**
     * Create a new folder.
     * 
     * @param path
     *            the path of the new folder.
     * @param path
     *            the target storage path.
     * @param localContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = request).
     * @param sessionContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = session).
     * @return the created folder.
     * @throws RTXException
     */
    public IResource createFolder(String path, Map localContext, Map sessionContext) throws RTXException;

    /**
     * Deletes a file or folder.
     * 
     * @param resource
     *            the resource to delete.
     * @throws RTXException
     */
    public void delete(IResource resource) throws RTXException;

}
