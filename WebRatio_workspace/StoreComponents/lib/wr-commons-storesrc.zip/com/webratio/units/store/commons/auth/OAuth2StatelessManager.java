package com.webratio.units.store.commons.auth;

import java.util.Map;

import com.webratio.rtx.RTXException;

/**
 * The implementation of the <code>IOAuthManager</code> based on <code>OAuth 2.0</code> protocol.
 */
public class OAuth2StatelessManager extends AbstractAuthorizationManager {

    private static final long serialVersionUID = 1L;

    public OAuth2StatelessManager(String accessToken) throws RTXException {
        super(null);
        this.accessToken = new AccessToken(accessToken);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialloginunit.IAuthManager#getAuthorizationUrl(java.lang.String)
     */
    public String getAuthorizationUrl(String callbackURL) throws RTXException {
        throw new RTXException("Do not have to be called for OAuth2StatelessManager!");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialloginunit.IAuthManager#authorize(java.util.Map, java.util.Map)
     */
    public boolean authorize(Map localContext, Map sessionContext) throws RTXException {
        throw new RTXException("Do not have to be called for OAuth2StatelessManager!");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IAuthManager#sign(java.util.Map)
     */
    public void sign(Map parameters) throws RTXException {
        if (accessToken != null) {
            parameters.put("access_token", accessToken.getValue());
        }
    }

}