package com.webratio.units.store.commons.application;

import com.webratio.rtx.RTXBLOBData;

/**
 * The generic interface of user's contact.
 */
public interface IContact {

    /**
     * Gets the contact identifier within the social network.
     * 
     * @return the contact identifier.
     */
    public String getId();

    /**
     * Gets the contact user name.
     * 
     * @return the contact user name.
     */
    public String getName();

    /**
     * Gets the contact user nick name.
     * 
     * @return the contact user nick name.
     */
    public String getNickName();

    /**
     * Gets the user location.
     * 
     * @return the user location.
     */
    public String getLocation();

    /**
     * Gets the contact profile image <code>RTXBLOBData</code>.
     * 
     * @return the contact profile image.
     */
    public RTXBLOBData getProfileImage();

    /**
     * Gets the web application the contact belongs to.
     * 
     * @return the web application.
     */
    public IApplication getApplication();

}
