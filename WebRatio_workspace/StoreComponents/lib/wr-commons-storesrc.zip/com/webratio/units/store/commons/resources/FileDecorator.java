package com.webratio.units.store.commons.resources;

import java.io.InputStream;
import java.security.InvalidParameterException;
import java.sql.Timestamp;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.webratio.rtx.RTXConstants;
import com.webratio.rtx.RTXException;
import com.webratio.rtx.RTXManager;
import com.webratio.rtx.core.SecurityConfig;
import com.webratio.rtx.security.DefaultUriSigner;
import com.webratio.rtx.security.RTXSigner;
import com.webratio.struts.HttpRequestHelper;
import com.webratio.struts.Requests;
import com.webratio.struts.UriBuilder;
import com.webratio.units.store.commons.application.IStorageService;

/**
 * The decorator implementation for resources having type {@link IResource#TYPE_FILE}.
 */
public class FileDecorator implements IDecoratedResource {

    private final IResource delegate;
    private final String url;

    public FileDecorator(IResource delegate, String servletPath, SecurityConfig securityConfig, Map localContext,
            HttpRequestHelper requestHelper, RTXManager rtx) throws RTXException {
        this.delegate = delegate;
        if (IResource.TYPE_FOLDER.equals(delegate.getType())) {
            throw new InvalidParameterException("This decorator is for files only");
        }
        String tempUrl = servletPath + "/" + delegate.getPath();
        try {
            HttpServletRequest request = (HttpServletRequest) localContext.get(RTXConstants.HTTP_SERVLET_REQUEST_KEY);
            UriBuilder uriBuilder = Requests.newUriBuilder(request);
            RTXSigner signer = Requests.getSigner(request, securityConfig);
            if (signer != null) {
                uriBuilder.setSigner(new DefaultUriSigner(signer, true, 1));
            }
            uriBuilder.setPath(tempUrl);
            uriBuilder.addParameter("cloudService", delegate.getService().getId());
            tempUrl = uriBuilder.build();
            if (delegate instanceof AbstractResource) {
                String openUrl = ((AbstractResource) delegate).getOpenUrl();
                if (openUrl != null) {
                    tempUrl = openUrl;
                }
            }
        } catch (RTXException e) {
            throw new RTXException("Unable to compute URL for resource " + delegate.getPath());
        }
        this.url = tempUrl;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getUrl()
     */
    public String getUrl() {
        return url;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#isFolder()
     */
    public boolean isFolder() {
        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getFolders()
     */
    public IResource[] getFolders() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getServiceIds()
     */
    public String[] getServiceIds() {
        return new String[] { delegate.getService().getId() };
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getServiceNames()
     */
    public String[] getServiceNames() {
        return new String[] { delegate.getService().getName() };
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getServices()
     */
    public IStorageService[] getServices() {
        return new IStorageService[] { delegate.getService() };
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getId()
     */
    public String getId() {
        return delegate.getId();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getName()
     */
    public String getName() {
        return delegate.getName();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getType()
     */
    public String getType() {
        return IResource.TYPE_FILE;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getFileExt()
     */
    public String getFileExt() {
        return delegate.getFileExt();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getSize()
     */
    public long getSize() {
        return delegate.getSize();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getLastModified()
     */
    public Timestamp getLastModified() {
        return delegate.getLastModified();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getMimeType()
     */
    public String getMimeType() {
        return delegate.getMimeType();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getPath()
     */
    public String getPath() {
        return delegate.getPath();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getService()
     */
    public IStorageService getService() {
        return delegate.getService();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getStorageContext()
     */
    public StorageContext getStorageContext() {
        return delegate.getStorageContext();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#listMembers()
     */
    public IResource[] listMembers() throws RTXException {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#delete()
     */
    public void delete() throws RTXException {
        delegate.delete();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getContents()
     */
    public InputStream getContents() throws RTXException {
        return delegate.getContents();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o) {
        return delegate.compareTo(o);
    }

}
