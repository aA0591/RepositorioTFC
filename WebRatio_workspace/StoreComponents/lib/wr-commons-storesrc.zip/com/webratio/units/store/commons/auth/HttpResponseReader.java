package com.webratio.units.store.commons.auth;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.json.JSONArray;
import org.json.JSONObject;

import com.webratio.rtx.RTXException;

/**
 * This class provides some utility method for reading HTTP responses.
 */
public class HttpResponseReader {

    public static JSONObject getJSonObject(HttpResponse response) throws RTXException {
        HttpEntity entity = response.getEntity();
        InputStream input = null;
        try {
            input = entity.getContent();
            return new JSONObject(IOUtils.toString(input, getEncoding(entity)));
        } catch (Exception e) {
            throw new RTXException("Unable to parse JSON object from HTTP response", e);
        } finally {
            IOUtils.closeQuietly(input);
        }
    }

    public static JSONArray getJSonArray(HttpResponse response) throws RTXException {
        HttpEntity entity = response.getEntity();
        InputStream input = null;
        try {
            input = entity.getContent();
            return new JSONArray(IOUtils.toString(input, getEncoding(entity)));
        } catch (Exception e) {
            throw new RTXException("Unable to parse JSON array object from HTTP response", e);
        } finally {
            IOUtils.closeQuietly(input);
        }
    }

    public static Element getDocumentElement(HttpResponse response) throws RTXException {
        HttpEntity entity = response.getEntity();
        InputStream input = null;
        try {
            input = entity.getContent();
            SAXReader reader = new SAXReader();
            Document doc = reader.read(input);
            return doc.getRootElement();
        } catch (Exception e) {
            throw new RTXException("Unable to parse Element object from HTTP response", e);
        } finally {
            IOUtils.closeQuietly(input);
        }
    }

    public static String getContentAsString(HttpResponse response) throws RTXException {
        HttpEntity entity = response.getEntity();
        InputStream input = null;
        try {
            input = entity.getContent();
            return IOUtils.toString(input, getEncoding(entity));
        } catch (Exception e) {
            throw new RTXException("Unable to read HTTP response", e);
        } finally {
            IOUtils.closeQuietly(input);
        }
    }

    private static String getEncoding(HttpEntity entity) {
        String charset = EntityUtils.getContentCharSet(entity);
        if (charset == null) {
            charset = HTTP.DEFAULT_CONTENT_CHARSET;
        }
        return charset;
    }

}
