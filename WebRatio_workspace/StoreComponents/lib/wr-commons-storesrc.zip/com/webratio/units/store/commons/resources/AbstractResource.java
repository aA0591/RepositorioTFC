package com.webratio.units.store.commons.resources;

import java.io.InputStream;
import java.sql.Timestamp;

import org.apache.commons.lang.StringUtils;

import com.webratio.rtx.RTXException;
import com.webratio.units.store.commons.application.IStorageService;

/**
 * The abstract resource.
 */
public class AbstractResource implements IResource {

    protected String id;
    protected String name;
    protected String fileExt;
    protected long size = -1;
    protected Timestamp lastModified;
    protected String path;
    protected String mimeType;
    protected String type;

    protected final IStorageService storageService;
    protected final StorageContext storageContext;

    protected AbstractResource(StorageContext storageContext) {
        this.storageService = storageContext.service;
        this.storageContext = storageContext;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getId()
     */
    public String getId() {
        return id;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getName()
     */
    public String getName() {
        return name;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getFileExt()
     */
    public String getFileExt() {
        return fileExt;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getType()
     */
    public String getType() {
        return type;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getSize()
     */
    public long getSize() {
        return size;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getLastModified()
     */
    public Timestamp getLastModified() {
        return lastModified;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getPath()
     */
    public String getPath() {
        return path;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getMimeType()
     */
    public String getMimeType() {
        return mimeType;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getService()
     */
    public IStorageService getService() {
        return storageContext.service;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getStorageContext()
     */
    public StorageContext getStorageContext() {
        return storageContext;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#listMembers()
     */
    public IResource[] listMembers() throws RTXException {
        if (IResource.TYPE_FOLDER.equals(type)) {
            return storageService.findMembers(this);
        }
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#delete()
     */
    public void delete() throws RTXException {
        storageService.delete(this);
    }

    public String getOpenUrl() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getContents()
     */
    public InputStream getContents() throws RTXException {
        if (IResource.TYPE_FOLDER.equals(type)) {
            throw new UnsupportedOperationException("Contents retrieval not supported on folders.");
        }
        return storageService.openInputStream(this);
    }

    protected String normalizePath(String toNormalize) {
        toNormalize = StringUtils.defaultString(toNormalize);
        toNormalize = StringUtils.replace(toNormalize, "\\", "/");
        if (!toNormalize.startsWith("/")) {
            toNormalize = "/" + toNormalize;
        }
        toNormalize = StringUtils.replace(toNormalize, "//", "/");
        return StringUtils.removeEnd(toNormalize, "/");
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return path;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o) {
        if (o instanceof IResource) {
            boolean f1 = IResource.TYPE_FOLDER.equals(getType());
            boolean f2 = IResource.TYPE_FOLDER.equals(((IResource) o).getType());
            if (f1 && !f2) {
                return -1;
            } else if (!f1 && f2) {
                return 1;
            }
            return StringUtils.defaultString(getName()).compareTo(StringUtils.defaultString(((IResource) o).getName()));
        }
        return 0;
    }

}
