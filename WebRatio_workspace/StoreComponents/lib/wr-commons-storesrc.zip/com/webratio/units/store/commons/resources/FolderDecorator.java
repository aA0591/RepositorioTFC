package com.webratio.units.store.commons.resources;

import java.io.InputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.webratio.rtx.RTXException;
import com.webratio.rtx.RTXManager;
import com.webratio.units.store.commons.application.IStorageService;

/**
 * The decorator implementation for resources having type {@link IResource#TYPE_FOLDER}.
 */
public class FolderDecorator implements IDecoratedResource {

    private final String name;
    private final String path;
    private final IStorageService[] services;
    private final String[] serviceIds;
    private final String[] serviceNames;
    private final IResource[] folders;
    private final ResourcesDecorator decorator;
    private final Map localContext;
    private final RTXManager rtx;

    public FolderDecorator(IResource[] folders, ResourcesDecorator decorator, Map localContext, RTXManager rtx) {
        this.folders = folders;
        this.decorator = decorator;
        this.localContext = localContext;
        this.rtx = rtx;
        this.name = folders[0].getName();
        this.path = folders[0].getPath();
        services = new IStorageService[folders.length];
        for (int i = 0; i < folders.length; i++) {
            services[i] = folders[i].getService();
        }
        Arrays.sort(services);
        serviceIds = new String[folders.length];
        serviceNames = new String[folders.length];
        for (int i = 0; i < services.length; i++) {
            serviceIds[i] = services[i].getId();
            serviceNames[i] = services[i].getName();
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getUrl()
     */
    public String getUrl() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#isFolder()
     */
    public boolean isFolder() {
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getServiceIds()
     */
    public String[] getServiceIds() {
        return serviceIds;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getServiceNames()
     */
    public String[] getServiceNames() {
        return serviceNames;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getServices()
     */
    public IStorageService[] getServices() {
        return services;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IDecoratedResource#getFolders()
     */
    public IResource[] getFolders() {
        return folders;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getId()
     */
    public String getId() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getName()
     */
    public String getName() {
        return name;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getFileExt()
     */
    public String getFileExt() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getType()
     */
    public String getType() {
        return IResource.TYPE_FOLDER;
    };

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getSize()
     */
    public long getSize() {
        return -1;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getLastModified()
     */
    public Timestamp getLastModified() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getPath()
     */
    public String getPath() {
        return path;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getMimeType()
     */
    public String getMimeType() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getService()
     */
    public IStorageService getService() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getStorageContext()
     */
    public StorageContext getStorageContext() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#listMembers()
     */
    public IResource[] listMembers() throws RTXException {
        List members = new ArrayList();
        for (int i = 0; i < folders.length; i++) {
            members.addAll(Arrays.asList(folders[i].listMembers()));
        }
        decorator.decorateResources(members, localContext, rtx);
        Collections.sort(members);
        return (IResource[]) members.toArray(new IResource[0]);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#delete()
     */
    public void delete() throws RTXException {
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.commons.resources.IResource#getContents()
     */
    public InputStream getContents() throws RTXException {
        throw new UnsupportedOperationException("Contents retrieval not supported on folders.");
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o) {
        if (o instanceof IResource) {
            boolean f1 = IResource.TYPE_FOLDER.equals(getType());
            boolean f2 = IResource.TYPE_FOLDER.equals(((IResource) o).getType());
            if (f1 && !f2) {
                return -1;
            } else if (!f1 && f2) {
                return 1;
            }
            return StringUtils.defaultString(getName()).compareTo(StringUtils.defaultString(((IResource) o).getName()));
        }
        return 0;
    }

}
