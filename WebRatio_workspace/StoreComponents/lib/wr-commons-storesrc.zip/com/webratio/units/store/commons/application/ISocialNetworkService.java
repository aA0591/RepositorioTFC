package com.webratio.units.store.commons.application;

import java.util.List;
import java.util.Map;

import com.webratio.rtx.RTXException;
import com.webratio.rtx.RTXService;
import com.webratio.units.store.commons.auth.IAuthorizationAwareService;

public interface ISocialNetworkService extends RTXService, IAuthorizationAwareService, IApplication {

    public static final String SOCIAL_NETWORK_PARAM = "sn";

    /**
     * Searches contacts by the given keywords.
     * 
     * @param keywords
     *            the searched keywords
     * @param localContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = request).
     * @param sessionContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = session).
     * @return a list of <code>IContact</code> objects.
     * @throws RTXException
     */
    public List searchContacts(String keywords, Map localContext, Map sessionContext) throws RTXException;

}
