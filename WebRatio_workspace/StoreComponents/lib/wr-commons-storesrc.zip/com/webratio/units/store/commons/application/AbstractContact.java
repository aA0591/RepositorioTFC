package com.webratio.units.store.commons.application;

import com.webratio.rtx.RTXBLOBData;

/**
 * The abstract application contact.
 */
public abstract class AbstractContact implements IContact {

    protected String id;
    protected String name;
    protected String nickName;
    protected String location;
    protected RTXBLOBData profileImage;
    protected transient final IApplication application;

    public AbstractContact(IApplication application) {
        this.application = application;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IContact#getId()
     */
    public String getId() {
        return id;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IContact#getName()
     */
    public String getName() {
        return name;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IContact#getNickName()
     */
    public String getNickName() {
        return nickName;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IContact#getLocation()
     */
    public String getLocation() {
        return location;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IContact#getProfileImage()
     */
    public RTXBLOBData getProfileImage() {
        return profileImage;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IContact#getApplication()
     */
    public IApplication getApplication() {
        return application;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return nickName + "[#" + id + "]";
    }

}
