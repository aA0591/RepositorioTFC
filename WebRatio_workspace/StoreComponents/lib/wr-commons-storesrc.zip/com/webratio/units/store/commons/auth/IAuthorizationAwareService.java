package com.webratio.units.store.commons.auth;

import java.util.Map;

import org.apache.http.HttpResponse;

import com.webratio.rtx.RTXException;
import com.webratio.units.store.commons.application.IIdentifiable;

/**
 * This interface, which can be implemented by application services, indicates that a service requires an authorization protocol.
 */
public interface IAuthorizationAwareService extends IIdentifiable {

    /**
     * Computes and returns the authentication URL.
     * 
     * @param callbackUrl
     *            the call back URL
     * @param localContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = request).
     * @param sessionContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = session).
     * @return the <code>OAuth</code> URL.
     * @throws RTXException
     *             in case of errors.
     */
    public String computeAuthorizationUrl(String callbackUrl, Map localContext, Map sessionContext) throws RTXException;

    /**
     * Authorizes the user and returns the access token.
     * 
     * @param localContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = request).
     * @param sessionContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = session).
     * @throws RTXException
     *             in case of errors.
     * @return the <code>AccessToken</code>.
     */
    public AccessToken getAccessToken(Map localContext, Map sessionContext) throws RTXException;

    /**
     * Returns <code>true</code> if the current user is authorized to access the social network.
     * 
     * @param localContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = request).
     * @param sessionContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = session).
     * @return <code>true</code> if the current user ia uthorized to access the social network.
     * @throws RTXException
     */
    public boolean isAuthorized(Map localContext, Map sessionContext) throws RTXException;

    /**
     * Initializes the authentication variables.
     * 
     * @param accessToken
     *            the access token.
     */
    public void init(AccessToken accessToken, Map localContext, Map sessionContext) throws RTXException;

    /**
     * Signouts the logged user from the social network.
     */
    public void logout(Map localContext, Map sessionContext) throws RTXException;

    /**
     * Reads the <code>AccessToken</code> parsing the given request.
     * 
     * @param response
     *            the <code>HttpResponse</code> to parse.
     * @return the access token.
     */
    public AccessToken readAccessToken(HttpResponse response);

}
