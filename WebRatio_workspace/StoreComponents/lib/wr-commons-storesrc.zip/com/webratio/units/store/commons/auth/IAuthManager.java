package com.webratio.units.store.commons.auth;

import java.io.Serializable;
import java.util.Map;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;

import com.webratio.rtx.RTXException;

/**
 * The interface of the authentication manager based on a generic two phases authorization protocol like OAuth or OpendID.
 */
public interface IAuthManager extends Serializable {

    /**
     * Gets the <code>HttpClient</code> instance.
     * 
     * @return the <code>HttpClient</code> instance.
     */
    public HttpClient getHTTPClient();

    /**
     * This method compute the authorization URL required by the underlying authorization protocol.
     * 
     * @param callbackURL
     *            the authorization callback URL.
     * @return the URL to navigate to authorize.
     * @throws RTXException
     *             in case an error occurs.
     */
    public String getAuthorizationUrl(String callbackURL) throws RTXException;

    /**
     * Creates the access token verifying the given verification code.
     * 
     * @param localContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = request).
     * @param sessionContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = session).
     * @return return <code>true</code> if the request is an authorization request.
     */
    public boolean authorize(Map localContext, Map sessionContext) throws RTXException;

    /**
     * Returns <code>true</code> if the access is granted to the underlying social network.
     * 
     * @return <code>true</code> in case of access granted.
     */
    public boolean isAuthorized();

    /**
     * Gets the access token used to sign requests.
     * 
     * @return the access token.
     */
    public AccessToken getAccessToken();

    /**
     * Sets the access token.
     * 
     * @param accessToken
     *            the access token to set.
     */
    public void setAccessToken(AccessToken accessToken);

    /**
     * Signs the given parameters map adding the extra required entries. This method is called before the request object creation.
     * 
     * @param request
     *            the request to sign.
     * @throws RTXException
     *             in case of signing exception.
     */
    public void sign(Map parameters) throws RTXException;

    /**
     * Signs the given <code>HttpRequestBase</code> object. This method is called after request object configuration.
     * 
     * @param request
     *            the request to sign.
     * @throws RTXException
     *             in case of signing exception.
     */
    public void sign(HttpRequestBase request) throws RTXException;

}