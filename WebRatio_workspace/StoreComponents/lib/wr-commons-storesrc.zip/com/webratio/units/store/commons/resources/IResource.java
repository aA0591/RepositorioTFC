package com.webratio.units.store.commons.resources;

import java.io.InputStream;
import java.sql.Timestamp;

import com.webratio.rtx.RTXException;
import com.webratio.units.store.commons.application.IStorageService;

/**
 * The generic interface of a resource located on a web application.
 */
public interface IResource extends Comparable {

    public static final String TYPE_FOLDER = "FOLDER";
    public static final String TYPE_FILE = "FILE";

    /**
     * The resource identifier (can be null, depends on the underlying web application).
     * 
     * @return the resource identifier.
     */
    public String getId();

    /**
     * The resource name.
     * 
     * @return the resource name.
     */
    public String getName();

    /**
     * Returns <code>FOLDER</code> in case the resource identifies a folder, <code>FILE</code> in case of file.
     * 
     * @return resource type.
     */
    public String getType();

    /**
     * Gets the resource path. The path starts with a "/" character but does not end with a "/" character.
     * 
     * @return the resource path.
     */
    public String getPath();

    /**
     * Gets the storage service the resource belongs to.
     * 
     * @return the storage service.
     */
    public IStorageService getService();

    /**
     * Gets the storage context of this resource.
     * 
     * @return the storage context.
     */
    public StorageContext getStorageContext();

    /**
     * Returns an open input stream on the contents of this file.
     * 
     * @return an input stream containing the contents of the file.
     * 
     * @throws RTXException
     */
    public InputStream getContents() throws RTXException;

    /**
     * Deletes the this resource. In case of folder deletes all members recursively.
     * 
     * @throws RTXException
     */
    public void delete() throws RTXException;

    /*
     * FILE SPECIFIC METHODS
     */

    /**
     * The file extension.
     * 
     * @return the file extension.
     */
    public String getFileExt();

    /**
     * Gets the file size, <code>-1</code> in case of folder.
     * 
     * @return the file size.
     */
    public long getSize();

    /**
     * Gets the resource last modified time.
     * 
     * @return the resource last modified time.
     */
    public Timestamp getLastModified();

    /**
     * The resource MIME type (can be null, depends on the underlying web application).
     * 
     * @return resource MIME type.
     */
    public String getMimeType();

    /*
     * FOLDER SPECIFIC METHODS
     */

    /**
     * Lists the members of the current resource.
     * 
     * @return the list of members (folder and files)
     * @throws RTXException
     */
    public IResource[] listMembers() throws RTXException;

}
