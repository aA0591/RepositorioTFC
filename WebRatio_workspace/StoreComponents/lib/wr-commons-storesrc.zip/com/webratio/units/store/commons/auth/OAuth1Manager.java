package com.webratio.units.store.commons.auth;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import oauth.signpost.OAuth;
import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthProvider;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.methods.HttpRequestBase;

import com.webratio.rtx.RTXConstants;
import com.webratio.rtx.RTXException;

/**
 * The implementation of the <code>IOAuthManager</code> based on <code>OAuth 1.0</code> protocol.
 */
public class OAuth1Manager extends AbstractAuthorizationManager {

    private static final long serialVersionUID = 1L;

    private final CommonsHttpOAuthProvider provider;
    private final CommonsHttpOAuthConsumer consumer;

    public OAuth1Manager(String reqTokenURI, String accessTokenURI, String apiAuthorize, String apiKey, String apiSecret,
            IAuthorizationAwareService service) {
        super(service);
        this.provider = new CommonsHttpOAuthProvider(reqTokenURI, accessTokenURI, apiAuthorize, getHTTPClient());
        this.consumer = new CommonsHttpOAuthConsumer(apiKey, apiSecret);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialunit.IAuthManager#computeAuthorizationUrl()
     */
    public String getAuthorizationUrl(String callbackURL) throws RTXException {
        try {
            String authURL = null;
            if (callbackURL == null) {
                authURL = provider.retrieveRequestToken(consumer, OAuth.OUT_OF_BAND);
            } else {
                authURL = provider.retrieveRequestToken(consumer, callbackURL);
            }
            // the authorization url should be used to redirect the user to the service provider where he/she
            // will enter user and password and thus will authorize the request token.
            // After authorization the user will be shown a verification ID, which must be used as
            // oauth_verifier parameter. This is required in OAuth 1.0a
            // However in OAuth 2-legged case we don't need this verification id
            // and we use null
            if (callbackURL == null) {
                provider.retrieveAccessToken(consumer, null);
            }
            return authURL;
        } catch (Exception e) {
            throw new RTXException("Unable to compute the OAuth URL", e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialloginunit.IAuthManager#authorize(java.util.Map, java.util.Map)
     */
    public boolean authorize(Map localContext, Map sessionContext) throws RTXException {
        if (accessToken != null) {
            return true;
        }
        HttpServletRequest request = (HttpServletRequest) localContext.get(RTXConstants.HTTP_SERVLET_REQUEST_KEY);
        if (consumer.getToken() == null || !consumer.getToken().equals(request.getParameter("oauth_token"))) {
            return false;
        }
        try {
            String oauthVerifier = StringUtils.defaultIfEmpty((String) request.getParameter("oauth_verifier"), null);
            provider.retrieveAccessToken(consumer, oauthVerifier);
            accessToken = new AccessToken(service, consumer.getToken() + "|" + consumer.getTokenSecret());
        } catch (Exception e) {
            throw new RTXException(e);
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialunit.IOAuthManager#setAccessToken(com.webratio.units.store.socialunit.AccessToken)
     */
    public void setAccessToken(AccessToken accessToken) {
        this.accessToken = accessToken;
        if (accessToken != null) {
            String[] token = StringUtils.split(accessToken.getValue(), "|");
            consumer.setTokenWithSecret(token[0], token[1]);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IAuthManager#sign(org.apache.http.client.methods.HttpRequestBase)
     */
    public void sign(HttpRequestBase request) throws RTXException {
        try {
            consumer.sign(request);
        } catch (Exception e) {
            throw new RTXException("Unable to sign the given request", e);
        }
    }

}