package com.webratio.units.store.commons.application;

import java.util.Map;

import com.webratio.rtx.RTXException;

public interface IApplication extends IIdentifiable {

    /**
     * Gets the social network home page.
     * 
     * @return the social network home page.
     */
    public String getHomePage();

    /**
     * Returns <code>true</code> if the application service requires a local login page.
     * 
     * @return <code>true</code> if the application service requires a local login page.
     */
    public boolean useLocalLoginPage();

    /**
     * Gets the current logged in user profile
     * 
     * @param localContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = request).
     * @param sessionContext
     *            a set of name-to-object bindings, preloaded with values of parameters (having scope = session).
     * @return the logged in user profile
     * @throws RTXException
     */
    public IUser getUser(Map localContext, Map sessionContext) throws RTXException;

}
