package com.webratio.units.store.commons.resources;

import java.io.InputStream;

import org.apache.http.entity.mime.MIME;
import org.apache.http.entity.mime.content.InputStreamBody;

public class InputStreamKnownSizeBody extends InputStreamBody {

    private long lenght;

    public InputStreamKnownSizeBody(InputStream input, long lenght, String filename) {
        super(input, MIME.ENC_BINARY, filename);
        this.lenght = lenght;
    }

    public long getContentLength() {
        return this.lenght;
    }
}