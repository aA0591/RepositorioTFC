package com.webratio.units.store.commons.resources;

import java.util.Map;

import com.webratio.units.store.commons.application.IStorageService;
import com.webratio.units.store.commons.auth.IAuthManager;

public class StorageContext {

    public final Map localContext;
    public final Map sessionContext;
    public final IAuthManager authMgr;
    public final IStorageService service;

    public StorageContext(Map localContext, Map sessionContext, IAuthManager authMgr, IStorageService service) {
        this.localContext = localContext;
        this.sessionContext = sessionContext;
        this.authMgr = authMgr;
        this.service = service;
    }

}
