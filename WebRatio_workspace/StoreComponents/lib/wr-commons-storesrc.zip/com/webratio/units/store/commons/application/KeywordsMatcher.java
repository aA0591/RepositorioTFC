package com.webratio.units.store.commons.application;

import org.apache.commons.lang.StringUtils;

public class KeywordsMatcher {

    public static boolean match(String content, String keywords) {
        if (StringUtils.isBlank(content)) {
            return false;
        }
        content = content.toLowerCase();
        keywords = keywords.toLowerCase();
        String[] tokens = StringUtils.split(keywords);
        for (int i = 0; i < tokens.length; i++) {
            if (!StringUtils.isBlank(tokens[i]) && !StringUtils.contains(content, tokens[i])) {
                return false;
            }
        }
        return true;
    }

}
