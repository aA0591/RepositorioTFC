package com.webratio.units.store.commons.application;

import com.webratio.rtx.RTXBLOBData;

/**
 * The abstract application user.
 */
public abstract class AbstractUser implements IUser {

    private static final long serialVersionUID = 1L;

    protected String id;
    protected String userName;
    protected String email;
    protected RTXBLOBData profileImage;
    protected RTXBLOBData largeProfileImage;
    protected transient final IApplication application;

    public AbstractUser(IApplication application) {
        this.application = application;
    }

    public String getId() {
        return id;
    }

    public String getUserName() {
        return userName;
    }

    public String getEmail() {
        return email;
    }

    public RTXBLOBData getProfileImage() {
        return profileImage;
    }

    public RTXBLOBData getLargeProfileImage() {
        return largeProfileImage;
    }

    public IApplication getApplication() {
        return application;
    }

    public String toString() {
        return userName + "[#" + id + "]";
    }

}
