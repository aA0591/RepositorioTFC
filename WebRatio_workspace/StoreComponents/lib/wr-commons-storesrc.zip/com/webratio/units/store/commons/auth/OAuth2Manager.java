package com.webratio.units.store.commons.auth;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;

import com.webratio.rtx.RTXConstants;
import com.webratio.rtx.RTXException;

/**
 * The implementation of the <code>IOAuthManager</code> based on <code>OAuth 2.0</code> protocol.
 */
public class OAuth2Manager extends AbstractAuthorizationManager {

    private static final long serialVersionUID = 1L;

    private final ServiceConsumer requestTokenService;
    private final ServiceConsumer accessTokenService;
    private final String apiKey;
    private final String apiSecret;

    /** The call back URL (required for the authorization phase) */
    private String callbackURL;

    public OAuth2Manager(String reqTokenURL, String accessTokenURL, String apiKey, String apiSecret, IAuthorizationAwareService service)
            throws RTXException {
        super(service);
        this.requestTokenService = new ServiceConsumer(reqTokenURL, this);
        this.accessTokenService = new ServiceConsumer(accessTokenURL, this);
        this.apiKey = apiKey;
        this.apiSecret = apiSecret;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialloginunit.IAuthManager#getAuthorizationUrl(java.lang.String)
     */
    public String getAuthorizationUrl(String callbackURL) throws RTXException {
        try {
            this.callbackURL = callbackURL;
            Map parameters = new HashMap();
            parameters.put("client_id", apiKey);
            parameters.put("redirect_uri", callbackURL);
            return requestTokenService.getEndpointURL(parameters);
        } catch (Exception e) {
            throw new RTXException("Unable to compute the OAuth URL", e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.socialloginunit.IAuthManager#authorize(java.util.Map, java.util.Map)
     */
    public boolean authorize(Map localContext, Map sessionContext) throws RTXException {
        HttpServletRequest request = (HttpServletRequest) localContext.get(RTXConstants.HTTP_SERVLET_REQUEST_KEY);
        String code = (String) request.getParameter("code");
        if (StringUtils.isBlank(code)) {
            return false;
        }
        try {
            Map parameters = new HashMap();
            parameters.put("client_id", apiKey);
            parameters.put("redirect_uri", this.callbackURL);
            parameters.put("client_secret", apiSecret);
            parameters.put("code", code);

            /* retrieves the access token */
            HttpResponse response = accessTokenService.doPost(parameters);
            accessToken = service.readAccessToken(response);
        } catch (Exception e) {
            throw new RTXException(e);
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.webratio.units.store.social.IAuthManager#sign(java.util.Map)
     */
    public void sign(Map parameters) throws RTXException {
        if (accessToken != null) {
            parameters.put("access_token", accessToken.getValue());
        }
    }

}