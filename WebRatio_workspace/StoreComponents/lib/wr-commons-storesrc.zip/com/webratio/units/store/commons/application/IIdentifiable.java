package com.webratio.units.store.commons.application;

public interface IIdentifiable extends Comparable {

    /**
     * Gets the service identifier.
     * 
     * @return the service identifier.
     */
    public String getId();

    /**
     * Gets the name of the service.
     * 
     * @return the service name.
     */
    public String getName();

}
