package com.webratio.units.store.commons.resources;

import com.webratio.units.store.commons.application.IStorageService;

/**
 * The interface for a resource decorator providing some utility extra methods.
 */
public interface IDecoratedResource extends IResource, Comparable {

    /**
     * Gets the URL which permits to access the resource contents (in case of file).
     * 
     * @return the URL accessing the resource contents.
     */
    public String getUrl();

    /**
     * Returns <code>true</code> in case this resource denotes a folder.
     * 
     * @return <code>true</code> in case this resource denotes a folder.
     */
    public boolean isFolder();

    /**
     * Gets the storage service identifiers this resource belongs to.
     * 
     * @return the storage service identifiers this resource belongs to.
     */
    public String[] getServiceIds();

    /**
     * Gets the storage service names this resource belongs to.
     * 
     * @return the storage service names this resource belongs to.
     */
    public String[] getServiceNames();

    /**
     * Gets the storage services this resource belongs to.
     * 
     * @return the storage services this resource belongs to.
     */
    public IStorageService[] getServices();

    /**
     * Get the real wrapped folders in case of virtual folder.
     * 
     * @return the real folders wrapped by this virtual folder.
     */
    public IResource[] getFolders();

}
