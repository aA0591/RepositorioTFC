package com.webratio.units.store.commons.auth;

import com.webratio.rtx.RTXException;

public class InvalidAccessTokenException extends RTXException {

    private static final long serialVersionUID = 1L;

    public InvalidAccessTokenException() {
        super();
    }

    public InvalidAccessTokenException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidAccessTokenException(String message) {
        super(message);
    }

    public InvalidAccessTokenException(Throwable cause) {
        super(cause);
    }

}
